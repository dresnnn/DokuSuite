---
name: "✨ Feature Request"
about: Neuer Funktionswunsch
title: ""
labels: ["type:feat"]
assignees: ""
---

## User Story
Als … möchte ich …, damit …

## Kontext & Nutzen
…

## Scope
- In: …
- Out (Nicht‑Ziele): …

## Acceptance Criteria (Gherkin)
- GIVEN … WHEN … THEN …
- …

## Metriken/Erfolg
…

## Abhängigkeiten
…
