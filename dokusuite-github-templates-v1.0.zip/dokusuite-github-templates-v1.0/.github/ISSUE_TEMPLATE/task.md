---
name: "🧰 Task"
about: Technische Aufgabe / Chore
title: ""
labels: ["type:chore"]
assignees: ""
---

## Beschreibung
…

## Definition of Done
- [ ] …
- [ ] …

## Checklist
- [ ] Tests (falls sinnvoll)
- [ ] Doku/README aktualisiert
- [ ] Telemetrie/Log ergänzt (falls sinnvoll)
