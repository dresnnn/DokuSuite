---
name: "✅ UAT Case"
about: Abnahmeszenario (Gherkin)
title: ""
labels: ["type:test"]
assignees: ""
---

## Szenario
GIVEN …
WHEN …
THEN …

## Vorbedingungen
…

## Testdaten
…

## Erwartete Artefakte
- UI‑Screenshot / Export / Log‑Eintrag …
